// If src/App.original.jsx exists, build src/App.jsx from it,
// swapping in the lavender GLOBAL_STYLES from lavender-styles.js.
import fs from 'node:fs';
const orig = 'src/App.original.jsx';
if (!fs.existsSync(orig)) { console.log('merge: no App.original.jsx, leaving App.jsx as is'); process.exit(0); }
const re = /^const GLOBAL_STYLES = `[\s\S]*?`;/m;
const styles = fs.readFileSync('lavender-styles.js', 'utf8').match(re);
let code = fs.readFileSync(orig, 'utf8');
if (!styles) throw new Error('lavender-styles.js has no GLOBAL_STYLES block');
if (!re.test(code)) throw new Error('App.original.jsx has no GLOBAL_STYLES block');
fs.writeFileSync('src/App.jsx', code.replace(re, () => styles[0]));
console.log('merge: wrote src/App.jsx with lavender styles');
