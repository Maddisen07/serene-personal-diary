export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 40 }}>
      <h1>Almost there</h1>
      <p>Paste your Serene code into <code>src/App.original.jsx</code> and redeploy.</p>
    </div>
  );
}
